﻿//***************************************
//Mahek Donga
//Project: Tetris Game
//Due: 13th March 2019
//***************************************

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class SceneChanger : MonoBehaviour {

    public void ToMenu()
    {
        SceneManager.LoadScene("Level");
    }
    public void To_Menu()
    {
        SceneManager.LoadScene("Menu");
    }
}
