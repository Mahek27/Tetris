﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Game : MonoBehaviour {
    public static int gridWidth = 10;   // the width of the grid
    public static int gridHeight = 20;  // the height of the grid

    // *****The grid**********
    public static Transform[,] grid = new Transform[gridWidth, gridHeight];

    public int scoreOneLine = 100;
    public int scoreTwoLine = 200;
    public int scoreThreeLine = 300;
    public int scoreFourLine = 800;

    public Text score_text;

    private int numberOfRowsThisTurn = 0;

    private int currentScore = 0;

    private GameObject previewTetromino;
    private GameObject nextTetromino;

    private bool gameStarted = false;

    private Vector2 previewTetrominoPosition = new Vector2(15, 10);

    //*********Spawn tetrominos**********
    void Start () {
        SpawnNextTetromino();
	}

    //*********Update**********
    void Update()
    {
        UpdateScore();
        UpdateUI();
    }

    //*********UpdateUI********
    public void UpdateUI()
    {
        score_text.text = currentScore.ToString();
    }

    //*********keep track of the score*********
    public void UpdateScore()
    {
        if (numberOfRowsThisTurn > 0){
            if (numberOfRowsThisTurn == 1)
            {
                clearOneLine();
            } else if (numberOfRowsThisTurn == 2)
            {
                clearTwoLine();
            } else if (numberOfRowsThisTurn == 3)
            {
                clearThreeLines();
            } else if (numberOfRowsThisTurn == 4)
            {
                clearFourLines();
            }
            numberOfRowsThisTurn = 0;
        }
    }

    public void clearOneLine()
    {
        currentScore += scoreOneLine;
    }
    public void clearTwoLine()
    {
        currentScore += scoreTwoLine;
    }
    public void clearThreeLines()
    {
        currentScore += scoreThreeLine;
    }
    public void clearFourLines()
    {
        currentScore += scoreFourLine;
        YouWin();
    }

    //*******Check If Any piceses that fall above the grid*********
    public bool CheckIsAboveGrid(Tetromino tetromino)
    {
        for (int x = 0; x < gridWidth; ++x)
        {
            foreach(Transform mino in tetromino.transform)
            {
                Vector2 pos = Round(mino.position);
                if ( pos.y > gridHeight - 1)
                {
                    return true;
                }
            }
        }
        return false;
    }

	// **********Clear the row if it is full in Grid(10x20)*************
    public bool IsFullRowAt (int y)
    {
        // The parameter y, is the row we will iterate over in the grid array to check each x position for a transform
        for (int x = 0; x < gridWidth; ++x)
        {
            // If we find the position that return NULL instead of transform, then we know that the row is not full
            if (grid[x,y] == null)
            {
                return false;
            }
        }

        numberOfRowsThisTurn++;
        // Iterate over the entier loop and didn't encounter any NULL position, then return true 
        return true;
    }

    // **********Delete the mino at position y************
    public void DeleteMinoAt(int y)
    {
        // The parameter y, is the row we will iterate over in the grid array
        for (int x = 0; x < gridWidth; ++x)
        {
            // Destroy the gameobject of each transform at the current iteration of x, y
            Destroy(grid[x,y].gameObject);
            
            // Set the x, y location in the grid array to null
            grid[x,y] = null;
        }
    }

    // **********Move the row down************
    public void MoveRowDown (int y)
    {
        // Iterate over each mino in the row of the y coordinate
        for (int x = 0; x < gridWidth; ++x)
        {
            // Check if current x and y in the grid array does not equal null 
            if (grid[x, y] != null)
            {
                // If it doesn't, then set current transform one position below in the grid
                grid[x, y - 1] = grid[x, y]; 
                // then set current transform to null
                grid[x, y] = null;
                // AND then adjust the position of the sprite to move down by one
                grid[x, y - 1].position += new Vector3(0, -1, 0);
            }
        }
    }

    // ***********Move all row down togather*************
    public void MoveAllRowsDown (int y)
    {
        // The y coordinate is the row above the row that was just deleted. So iterate over each row starting with that one all the way to the height of the grid
        for (int i = y; i < gridHeight; ++i)
        {
            // then call MoveRowDown for each iteration
            MoveRowDown(i);
        }
    }

    // ***********Delete row if it is full**************
    public void DeleteRow()
    {
        // After receiving the call from the tetromino class, iterate over all the y position to gridHeight
        for (int y = 0; y < gridHeight; ++y)
        {
            // At each iteration check if row is full
            if (IsFullRowAt(y))
            {
                // If it is, call DeleteMinoAt and pass in the current y
                DeleteMinoAt(y);
                MoveAllRowsDown(y + 1);
                --y;
            }
        }
    }

    // **************Update grid position******************
    public void UpdateGrid (Tetromino tetromino)
    {
        // In this method, update the grid array, do this by starting for loop that iterate over all the grid rows starting at 0
        for (int y = 0; y < gridHeight; ++y)
        {
            // For each row, iterate over each individuals x coordinate that represent a spot on the grid where a mino could be
            for (int x = 0; x < gridWidth; ++x)
            {
                if (grid [x,y] != null)
                {
                    if (grid[x,y].parent == tetromino.transform)
                    {
                        grid[x, y] = null;
                    }
                }
            }
        }
        foreach (Transform mino in tetromino.transform)
        {
            Vector2 pos = Round (mino.position);
            if(pos.y < gridHeight)
            {
                grid[(int)pos.x, (int)pos.y] = mino;
            }
        }
    }
    
    // **************Trasform at the grid position***************
    public Transform GetTransformAtGridPosition (Vector2 pos)
    {
        if (pos.y > gridHeight - 1)
        {
            return null;
        } else
        {
            return grid[(int)pos.x, (int)pos.y];
        }
    }

    // ***************Spawn tetromino***************
    public void SpawnNextTetromino()
    {
        if (!gameStarted)
        {
            gameStarted = true;

            // Spawn another tetrominos from the resources assets folder using the GetRandomTetromino method to select rendom prefabs
            nextTetromino = (GameObject)Instantiate(Resources.Load(GetRandomTetromino(), typeof(GameObject)), new Vector2(5.0f, 20.0f), Quaternion.identity);
            previewTetromino = (GameObject)Instantiate(Resources.Load(GetRandomTetromino(), typeof(GameObject)), previewTetrominoPosition, Quaternion.identity);
            previewTetromino.GetComponent<Tetromino>().enabled = false;

        } else
        {
            previewTetromino.transform.localPosition = new Vector2(5.0f, 20.0f);
            nextTetromino = previewTetromino;
            nextTetromino.GetComponent<Tetromino>().enabled = true;

            previewTetromino = (GameObject)Instantiate(Resources.Load(GetRandomTetromino(), typeof(GameObject)), previewTetrominoPosition, Quaternion.identity);
            previewTetromino.GetComponent<Tetromino>().enabled = false;
        }

        
    }

    // ************Check tetromino inside the grid**************
    public bool CheckIsInsideGrid (Vector2 pos)
    {
        return ((int)pos.x >= 0 && (int)pos.x < gridWidth && (int)pos.y >= 0);
    }

    public Vector2 Round (Vector2 pos)
    {
        return new Vector2(Mathf.Round(pos.x), Mathf.Round(pos.y));
    }

    //**************Generate tetromino**************
    string GetRandomTetromino()
    {
        // used Random.Range to generate random number between 1 to 8 
        int randomTetromino = Random.Range(1, 8);

        // the create a string variable with an identifier of randomTetrominoName and assign it a default value of Tetromino_T
        string randomTetrominoName = "Prefabs/Tetromino_T";

        // used switch condition to test for each possible random number case and then assign a different prefabs name to the randomTetrominoName variable
        switch (randomTetromino)
        {
            case 1:
                randomTetrominoName = "Prefabs/Tetromino_I";
                    break;
            case 2:
                randomTetrominoName = "Prefabs/Tetromino_T";
                break;
            case 3:
                randomTetrominoName = "Prefabs/Tetromino_Z";
                break;
            case 4:
                randomTetrominoName = "Prefabs/Tetromino_S";
                break;
            case 5:
                randomTetrominoName = "Prefabs/Tetromino_O";
                break;
            case 6:
                randomTetrominoName = "Prefabs/Tetromino_L";
                break;
            case 7:
                randomTetrominoName = "Prefabs/Tetromino_J";
                break;
        }
        return randomTetrominoName;
    }

    // **************Load scene****************
    public void GameOver()
    {
        SceneManager.LoadScene("GameOver");
    }
    public void YouWin()
    {
        SceneManager.LoadScene("YouWin");
    }
}
