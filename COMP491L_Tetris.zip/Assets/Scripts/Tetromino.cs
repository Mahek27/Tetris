﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tetromino : MonoBehaviour {

    float fall = 0;                     // countdown timer for fall speed
    public float fallSpeed = 1;         

    public bool allowRotation = true;   // Use this to specify if we want to allow the tetrominos to rotate 
    public bool limitRotation = false;  // this is use to limit the rotation of the tetromios to 90 / -90 rotation

	void Start () {
		
	}
	 
	// ***********Update this instance************
	void Update () {
        CheckUserInput();

    }

    // ***********check the user input************
    void CheckUserInput()
    {
        // This methods checks the keys that the player can press to manupilate the position of the tetrominos.
        // The options here will be Left, Right, Up, Down, and SpaceBar
        // left and right will move the one unit left or right
        // down will move the one unit down
        // Up will rotate the tetrominos
        // space will quickly drop down the tetrominos

        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.position += new Vector3(1, 0, 0);

            // Check if tetrominos is at a valid position
            if (CheckIsValidPosition())
            {
                // if it is, then call UpdateGrid method which records this tetrominos new position.
                FindObjectOfType<Game>().UpdateGrid(this);
            } else {
                
                // if it isn't, move tetrominos to the left
                transform.position += new Vector3(-1, 0, 0);
            }

        } else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.position += new Vector3(-1, 0, 0);

            // check if tetrominos is at a valid position
            if (CheckIsValidPosition())
            {

                FindObjectOfType<Game>().UpdateGrid(this);
            } else {

                transform.position += new Vector3(1, 0, 0);
            }

        } else if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            // The up key was pressed, lets first check if the tetrominos allow to rotate
            if (allowRotation)
            {
                // if it is, then need to check if rotation is limited to just back and forth
                if (limitRotation)
                {
                    // if it is, then need to check what current rotation is
                    if (transform.rotation.eulerAngles.z >= 90)
                    {
                        // if it is at 90, then we know it is already rotated, so rotate it back to -90
                        transform.Rotate(0, 0, -90);
                    }
                    else
                    {
                        // if it isn't, then rotate it to 90
                        transform.Rotate(0, 0, 90);
                    }

                }
                else
                {
                    // if it isn't, then rotate it to 90
                    transform.Rotate(0, 0, 90);
                }
                
                // now check if the tetrominos at valid position after attempting the rotation
                if (CheckIsValidPosition()) {

                    // if position is valid then update the grid
                    FindObjectOfType<Game>().UpdateGrid(this);

                } else {
                    if (limitRotation)
                    {
                        // if it isn't, then rotate it to -90
                        if (transform.rotation.eulerAngles.z >= 90)
                        {
                            transform.Rotate(0, 0, -90);
                        }
                        else
                        {
                            transform.Rotate(0, 0, 90);
                        }

                    } else
                    {
                        transform.Rotate(0, 0, -90);
                    }
                }
                
           }

        } else if (Input.GetKey(KeyCode.Space) || Input.GetKeyDown(KeyCode.DownArrow) || Time.time - fall >= fallSpeed)
        {
            // used down arrow to move down one unit or use spacebar to move down quickly
            transform.position += new Vector3(0, -1, 0);

            if (CheckIsValidPosition()) {

                FindObjectOfType<Game>().UpdateGrid(this);

            } else {
                transform.position += new Vector3(0, 1, 0);

                FindObjectOfType<Game>().DeleteRow();

                // check if there are any minos above the grid
                if (FindObjectOfType<Game>().CheckIsAboveGrid(this))
                {
                    FindObjectOfType<Game>().GameOver();
                }

                enabled = false;
                // spawn the next piece
                FindObjectOfType<Game>().SpawnNextTetromino();
            }
            fall = Time.time;
        }
    }

    //**************check is valid position***************
    // return TRUE if valid position was checked, otherwise return FALSE
    bool CheckIsValidPosition()
    {
        foreach(Transform MinoGrid in transform)
        {
            Vector2 pos = FindObjectOfType<Game>().Round(MinoGrid.position);
            if (FindObjectOfType<Game>().CheckIsInsideGrid(pos) == false)
            {
                return false;
            }
            if (FindObjectOfType<Game>().GetTransformAtGridPosition(pos) != null && FindObjectOfType<Game>().GetTransformAtGridPosition(pos).parent != transform)
            {
                return false;
            }
        }
        return true;
    }

}
